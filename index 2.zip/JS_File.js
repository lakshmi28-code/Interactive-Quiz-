var savedemail = "";
var savedpass = "";
var savedname = "";

function showRegister() {
  document.getElementById("loginpage").style.display="none";
  document.getElementById("registerpage").style.display="block";
  document.getElementById("welcomepage").style.display="none";
}

function showLogin() {
  document.getElementById("registerpage").style.display="none";
  document.getElementById("welcomepage").style.display="none";
  document.getElementById("loginpage").style.display="block";
  document.getElementById("loginemail")="";
  document.getElementById("loginpass")="";
}

function register() {
  var name = document.getElementById("regname").value;
  var email = document.getElementById("regemail").value;
  var pass = document.getElementById("regpass").value;
  var repeat = document.getElementById("regrepeat").value;

if (name === "" || email === "" || pass === "" || repeat === "") 
{
    alert("Please fill all details.");
    return;
}

if(!email.includes("@gmail.com"))
{
    alert("Include '@gmail.com' in E-mail field");
    return;
}

if (pass !== repeat) 
{
    alert("Passwords do not match.");
    return;
}

savedname = name;
savedemail = email;
savedpass = pass;

document.getElementById("registerpage").style.display = "none";
document.getElementById("welcomepage").style.display = "block";
document.getElementById("welcometext").innerText = "Hello, " + name;
}

function login() 
{
  var email = document.getElementById("loginemail").value;
  var pass = document.getElementById("loginpass").value;

  if (email === "" || pass === "") {
    alert("Fill the details properly.");
    return;
  }

  if(!email.includes('@gmail.com'))
  {
    alert("Include '@gmail.com' in E-mail field");
    return;
  }

  if (email === savedemail && pass === savedpass) {
    document.getElementById("loginpage").style.display = "none";
    document.getElementById("welcomepage").style.display = "block";
    document.getElementById("welcometext").innerText = "Hello, " + savedname;
  } 
  else 
  {
    alert("Account doesn't exist.");
    document.getElementById("loginpage").style.display = "none";
    document.getElementById("registerpage").style.display = "block";
  }
}